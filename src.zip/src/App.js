import React, {Component} from "react";
import axios from "axios";

let config = {
  foodDataItems : "",
}
class Foodapp extends Component{
  state = {
    foodData : [],
    foodCategory :["all", "breakfast", "lunch", "shakes"]
  }
  
  componentDidMount(){
    axios.get(`http://localhost:3004/food`)
      .then((response)=> {
        this.setState({
          foodData : response.data,
        });
        config.foodDataItems = response.data;
      })
      .catch((error)=>{
        console.log("data notfound")
      })
  }
  foodCategoryClick(event){
    const activemenuText = event.target.textContent;
    let filterData = config.foodDataItems.filter((item)=>{
      return item.category == activemenuText;
    });
   this.setState({
    foodData : filterData.length != 0  ? filterData : config.foodDataItems
   })
  }
  render() {
    const food = this.state.foodData;
    const foodCategoryItem = this.state.foodCategory;
    return(
      <>  
        <main>
          <section className="menu section">
              <div className="title">
                <h2>our menu</h2>
                <div className="underline"></div>
              </div>
              <div className="btn-container">
                {
                  foodCategoryItem.map((item,index)=>(
                    <button type="button" className="filter-btn" key={index++} onClick={(e)=>this.foodCategoryClick(e)}>{item}</button>
                  ))
                }
              </div>
              <div className="section-center">
                {
                  food.map((foodItem) => (
                    <article className="menu-item" key={foodItem.id}>
                      <img src={foodItem.img} alt="buttermilk pancakes" className="photo"></img>
                      <div className="item-info">
                        <header>
                            <h4>{foodItem.title}</h4>
                            <h4 className="price">${foodItem.price}</h4>
                        </header>
                        <p className="item-text">{foodItem.desc}</p>
                      </div>
                    </article>
                  ))
                }
              </div>
          </section>
        </main>
      </>
    )
  }
}
export default Foodapp;
